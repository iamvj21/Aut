﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspDotNetCoreMVC.Models;
using AspDotNetCoreMVC.Data;
using Microsoft.AspNetCore.Authorization;

namespace WebApplication2MVCDatabaseFirst.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ProductController : Controller
    {
        
        public readonly ApplicationDbContext _context;
        public ProductController (ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var cat = _context.Category.ToList();
            ViewBag.SubCategory= _context.SubCategory.ToList();
            ViewBag.Product = _context.MainProduct.ToList();
            return View(cat);
        }
        public IActionResult AddCategory()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddCategory(Category category)
        {
            if (category != null)
            {

            _context.Category.Add(category);
            _context.SaveChanges();
            return RedirectToAction("Index");
            }
            return View();
        }

        public IActionResult AddSubCategory()
        {
            var catego = _context.Category.ToList();
            ViewBag.Categories = new SelectList(catego,"CategoryID","CategoryName");
            return View();
        }
        [HttpPost]
        public IActionResult AddSubCategory(SubCategory subcategory)
        {
            if (subcategory != null)
            {

            _context.SubCategory.Add(subcategory);
            _context.SaveChanges();
            return RedirectToAction("Index");
            }
            return View();
        }
        public IActionResult AddProduct()
        {
            var catego = _context.SubCategory.ToList();
            ViewBag.SubCategory = new SelectList(catego, "SubCategoryID", "SubCategoryName");
            return View();
        }
        [HttpPost]
        public IActionResult AddProduct(MainProduct mainproduct)
        {
            if (mainproduct != null)
            {

            _context.MainProduct.Add(mainproduct);
            _context.SaveChanges();
            return RedirectToAction("Index");
            }
            return View();
        }
    }
}
