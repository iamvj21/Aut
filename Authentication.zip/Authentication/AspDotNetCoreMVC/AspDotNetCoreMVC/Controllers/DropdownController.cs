﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspDotNetCoreMVC.Models;
using AspDotNetCoreMVC.Data;

namespace AspDotNetCoreMVC.Controllers
{
    public class DropdownController : Controller
    {
        public readonly ApplicationDbContext _context;
        public DropdownController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            List<Category> categoryList = new List<Category>();
            categoryList = (from Category in _context.Category
                            select Category).ToList();
            categoryList.Insert(0, new Category { CategoryID = 0, CategoryName = "Select" });

            ViewBag.ListOfCategory = categoryList;
            return View();
        }

        public IActionResult showData()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Category objcategory)
        {
           

            var CategoryID = objcategory.CategoryID;
            var SubCategoryID = objcategory.SubCategoryID;
            var ProductID = objcategory.ProductID; 

            var productName = (from product in _context.MainProduct
                               where product.ProductID == objcategory.ProductID
                               select product.ProductName).FirstOrDefault();
            var SubCategoryName = (from product in _context.SubCategory
                               where product.SubCategoryID == objcategory.SubCategoryID
                               select product.SubCategoryName).FirstOrDefault();
            var CategoryName = (from product in _context.Category
                               where product.CategoryID == objcategory.CategoryID
                               select product.CategoryName).FirstOrDefault();
            
            TempData.Add("CategoryName", CategoryName);
            TempData.Add("SubCategoryName", SubCategoryName);
            TempData.Add("ProductName", productName);

            return RedirectToAction("showData");
        }

        public JsonResult GetSubCategory(int CategoryID)
        {
            List<SubCategory> subCategorylist = new List<SubCategory>();

            // ------- Getting Data from Database Using EntityFrameworkCore -------
            subCategorylist = (from subcategory in _context.SubCategory
                               where subcategory.CategoryID == CategoryID
                               select subcategory).ToList();

            // ------- Inserting Select Item in List -------
            subCategorylist.Insert(0, new SubCategory { SubCategoryID = 0, SubCategoryName = "Select" });


            return Json(new SelectList(subCategorylist, "SubCategoryID", "SubCategoryName"));
        }

        public JsonResult GetProducts(int SubCategoryID)
        {
            List<MainProduct> productList = new List<MainProduct>();

            // ------- Getting Data from Database Using EntityFrameworkCore -------
            productList = (from product in _context.MainProduct
                           where product.SubCategoryID == SubCategoryID
                           select product).ToList();

            // ------- Inserting Select Item in List -------
            productList.Insert(0, new MainProduct { ProductID = 0, ProductName = "Select" });

            return Json(new SelectList(productList, "ProductID", "ProductName"));
        }

    }
}
